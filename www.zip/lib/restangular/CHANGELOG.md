
1.5.1 / 2015-04-03
==================

  * Release 1.5.0
  * Updated zip
  * Merge branch 'master' of github.com:mgonto/restangular
  * Merge pull request #1081 from rajeshwarpatlolla/develop
  * Merge pull request #1079 from wching/master
  * change in README file
  * url modified for 'Chain methods together to easily build complex requests'
  * Update README.md
  * Update README.md

1.5.0 / 2015-04-03
==================
* Tons of bug fixes
* Upgraded Lodash to 1.3.0
